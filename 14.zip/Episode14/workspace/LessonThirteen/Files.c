/*
 * Files.c
 *
 *  Created on: 16 июн. 2017 г.
 *      Author: ivanovcinnikov
 */
#include <stdio.h>

int main (int argc, const char* argv[]) {

	FILE *f;
	f = fopen("filename.txt", "w");		// r = read, w = write, a = append, rb, wb, ab
	if (f == NULL) return 1;
	fprintf(f, "Hello, files! %s", "we did it! \n");
	fclose(f);

	char word[256];
	f = fopen("filename.txt", "r");
	while (!feof(f)) {
		fscanf(f, "%s ", &word);
		printf("%s ", word);
	}
	fclose(f);
	puts("");
	return 0;
}
