/*
 * header.h
 *
 *  Created on: 31 мая 2017 г.
 *      Author: ivanovcinnikov
 */

#ifndef HEADER_H_
#define HEADER_H_

int isPrime (int number) {
	int d = 0, i = 1;
		while (i <= number) {
			if (number % i++ == 0)
				d++;
			else
				continue;
			if (d == 3) return 0;
		}
//		if(d == 2) return 1; else return 0;
//		return (d == 2) ? 1 : 0;
		return (d == 2);
}


#endif /* HEADER_H_ */
/*
 * header.h
 *
 *  Created on: 31 мая 2017 г.
 *      Author: ivanovcinnikov
 */

#ifndef HEADER_H_
#define HEADER_H_

int isPrime (int number) {
	int d = 0, i = 1;
		while (i <= number) {
			if (number % i++ == 0)
				d++;
			else
				continue;
			if (d == 3) return 0;
		}
//		if(d == 2) return 1; else return 0;
//		return (d == 2) ? 1 : 0;
		return (d == 2);
}


#endif /* HEADER_H_ */
